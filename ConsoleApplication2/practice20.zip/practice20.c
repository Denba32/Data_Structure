#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>


#define MAX 101

typedef char element;

element data[MAX];
bool result = false;
typedef struct {
	element data[MAX];
	int top;
}StackType;


// Stack Empty Check
int isEmpty(StackType* s)
{
	return (s->top == -1);
}

// Stack Full Check
int isFull(StackType* s)
{
	return (s->top == MAX - 1);
}


// Push Item in Stack
void Push(StackType* s, element datas)
{
	if (isFull(s))
	{
		printf("Error, Stack is Full!");
		return;
	}
	else {
		s->data[++(s->top)] = datas;
	}
}

// Pop Item in Stack
element Pop(StackType* s)
{
	if (isEmpty(s))
	{
		printf("Error, Stack is Empty!");
		exit(1);
	}
	else {
		return s->data[(s->top)--];
	}
}

// peek Item in Stack
element peek(StackType* s)
{
	if (isEmpty(s))
	{
		printf("Error, Stack is Empty!");
		return;
	}

	return s->data[(s->top)];
}

// Stack Initializing
void Init(StackType* s)
{
	if (isEmpty(s))
	{
		printf("Error, Stack is Empty!");
		return;
	}

	s->top = -1;
}


int main() {
	StackType s;
	Init(&s);
	bool repeat = true;
	char question[MAX];
	char temp[MAX];
	while (repeat)
	{
		printf("\n");
		printf("���ڿ��� �Է��Ͻÿ�: ");
		scanf("%[^\n\r]", &data);

		int r = 0;
		for (int i = 0; i < strlen(data); i++)
		{
			if (data[i] != ' ')
			{
				temp[r] = data[i];
				r++;
			}
			if (!isdigit(data[i]))
			{
				;
			}
		}
		temp[r] = '\0';

		int length = strlen(temp);

		// �ѱ��ھ� �־���
		for (int i = 0; i < length; i++)
		{
			
			if (temp[i] >= 65 && temp[i] <= 90)
			{
				Push(&s, temp[i] + 32);
			}
			else {
				Push(&s, temp[i]);
			}
		}

		for (int i = 0; i < length; i++)
		{
			char tip = Pop(&s);
			if (tip == temp[i])
			{
				result = true;
			}
			else {
				result = false;
				printf("ȸ���� �ƴմϴ�\n");
				break;
			}
		}
		if (result)
			printf("ȸ���Դϴ�.\n");

		printf("��� �Է��Ͻðڽ��ϱ�(Yes/No): ");
		scanf("%s", &question);
		if (strcmp(question, "Yes") == 0 || strcmp(question, "yes") == 0)
		{
			data[MAX] = "";
			repeat = true;
		}
		else if (strcmp(question, "No") == 0 || strcmp(question, "no") == 0)
		{
			repeat = false;
		}

	}
}
// �����͸� ����
// Push �� ���Ͽ� ���� Element �迭�� ���� �ϳ��� �� �� �����ϸ� ȸ���Դϴ�
// �������� ������ ȸ���� �ƴմϴ�.�� �亯