#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

#define _CRT_SECURE_NO_WARNINGS

typedef int element;

element item;

int moveCount;

int index;

typedef struct ListNode{
	element data;
	struct ListNode* link;
}ListNode;

void error(char* message) {
	printf("%s\n", message);
	exit(1);
}

ListNode* insert_first(ListNode* head, element value) {

	ListNode* p;
	p =(ListNode*)malloc(sizeof(ListNode));
	p->data = value;
	p->link = head;
	head = p;
	return head;
}

ListNode* insert(ListNode* head, int pos, element value) {
	ListNode* p = head;
	int count = 0;
	while (p != NULL) {

		if (count == pos) {

		}

		// ������ �Ѿ�� 
		else {
			if (p == NULL) {
				ListNode* data;
				data = (ListNode*)malloc(sizeof(ListNode));
				printf("The last index is %d. Insert at the end of the list..\n", count - 1);
				data->data = value;
				data->link = p->link;
				p->link = data;
				
			}
		}
		p = p->link;
		count++;
	}
}
/*
ListNode* insert(ListNode* head, ListNode* pre, element value) {

	ListNode* p = (ListNode*)malloc(sizeof(ListNode));

	p->data = value;
	p->link = pre->link;
	pre->link = p;
	return head;
}
*/
ListNode* delete_first(ListNode* head) {
	ListNode* removed;
	if (head == NULL) return NULL;
	removed = head;
	head = removed->link;

	free(removed);

	return head;
}

ListNode* delete(ListNode* head, ListNode* pre) {
	ListNode* removed;
	removed = pre->link;
	pre->link = removed->link;
	free(removed);
	return head;
}

void print_list(ListNode* head) {
	printf("List: ");
	for (ListNode* p = head; p != NULL; p = p->link)
		printf("%d->", p->data);
	printf("NULL \n");
}

int main() {
	int selector = 0;

	ListNode* head = NULL;

	while (1) {
		printf("Menu\n(1) Insert\n(2) Delete\n(3) Print\n(0) Exit\nEnter the menu: ");
		scanf("%d", &selector);
		getchar();


		// insert
		if (selector == 1) {
			printf("Enter the number and position: ");
			scanf("%d ,%d", &item, &index);
			getchar();

			if (head == NULL) {
				printf("List is empty. Insert at position 0..\n");
				head = insert_first(head, item);
			}
			else {
				insert(head, item);

			}
		}

		// Delete
		else if (selector == 2) {
			if (head == NULL) {
				printf("List is empty.\n\n");
			}
			else {
				printf("Enter the position: ");
				scanf("%d", &index);
				getchar();
			}

		}

		// Print
		else if (selector == 3) {
			print_list(head);
		}

		// Exit
		else if (selector == 0) {
			printf("Exit the program.\n");
			exit(1);
		}

		else {
			printf("Invalid Menu. Please select again..\n\n");
			continue;
		}
		printf("\n");

	}
}