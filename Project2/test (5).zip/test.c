﻿#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 100
#define MAZE_SIZE 10

//typedef char element;
char str[101];
int count = 0;

int check = 0;
char maze[MAZE_SIZE][MAZE_SIZE] = {
		{'1','1','1','1','1','1','1','1','1','1'},
		{'e','1','0','1','0','0','0','1','0','1'},
		{'0','0','0','1','0','0','0','1','0','1'},
		{'0','1','0','0','0','1','1','0','0','1'},
		{'1','0','0','0','1','0','0','0','0','1'},
		{'1','0','0','0','1','0','0','0','0','1'},
		{'1','0','0','0','0','0','1','0','1','1'},
		{'1','0','1','1','1','0','1','1','0','1'},
		{'1','1','0','0','0','0','0','0','0','x'},
		{'1','1','1','1','1','1','1','1','1','1'}
};

char temp[MAZE_SIZE][MAZE_SIZE];


typedef struct {
	short r;
	short c;
}element;

element here = { 1,0 };
element entry = { 1,0 };

// 구조체용
typedef struct {
	element data[MAX];
	int top;
}StackType;


// 비어있을 때
int isEmpty(StackType *s)
{
	return (s->top == -1);
}
// 가득 찼을 때
int isFull(StackType* s)
{
	return (s->top == MAX - 1);
}
void Init_Stack(StackType* s)
{
	s->top = -1;
}

void Push(StackType* s, element datas)
{
	if (isFull(s))
	{
		printf("Error, Stack is Full!");
		return;
	}
	else {
		s->data[++(s->top)] = datas;
	}
}

element Pop(StackType* s)
{
	if (isEmpty(s))
	{
		printf("Error, Stack is Empty!");
		return;
	}
	else {
		return s->data[(s->top)--];
	}
}

element peek(StackType* s)
{
	if (isEmpty(s))
	{
		printf("Error, Stack is Empty!");
		return;
	}

	return s->data[(s->top)];
}

void Init(StackType* s)
{
	if (isEmpty(s))
	{
		printf("Error, Stack is Empty!");
		return;
	}

	s->top = -1;
}


// 0 미만이거나 1 초과일 경우
void push_loc(StackType* s, int r, int c) {
	if (r < 0 || c < 0) return;
	if (maze[r][c] != '1' && maze[r][c] != '.') {
		element tmp;
		tmp.r = r;
		tmp.c = c;
		Push(s, tmp);
	}
	else {
		check++;
	}
}

void push_back(StackType* s, int r, int c)
{
	if (r < 0 || c < 0) return;
	if (maze[r][c] != '1' && maze[r][c] == '.') {
		element tmp;
		tmp.r = r;
		tmp.c = c;
		Push(s, tmp);
	}
}


void maze_print(char maze[MAZE_SIZE][MAZE_SIZE])
{
	printf("\n");
	for (int r = 0; r < MAZE_SIZE; r++) {
		for (int c = 0; c < MAZE_SIZE; c++) {
			printf("%c", maze[r][c]);
		}
		printf("\n");
	}
}

// direction
// 하상좌우

int main() 
{
	int r, c;
	// 경로 체크용
	StackType s;
	StackType temp;

	Init(&temp);
	Init(&s);
	here = entry;

	while (maze[here.r][here.c] != 'x') {
		r = here.r;
		c = here.c;
		// 실질적으로 위치를 찍는 부분
		maze[r][c] = '.';
		//maze_print(maze);

		// 하 상 좌 우 순으로 이동할 수 있는지 검증
		push_loc(&s, r - 1, c);
		push_loc(&s, r + 1, c);
		push_loc(&s, r, c - 1);
		push_loc(&s, r, c + 1);

		// 상하좌우가 다 막힘
		if (check == 4)
		{
			push_back(&s, r - 1, c);
			push_back(&s, r + 1, c);
			push_back(&s, r, c - 1);
			push_back(&s, r, c + 1);
		}

		check = 0;

		if (check != 0)
		{
			while (check != 0) {
				//if(Pop(&temp)
			}

		}
		if (isEmpty(&s)) {
			printf("실패\n");
			return;
		}
		else
		{
			here = Pop(&s);
			if (maze[here.r][here.c] == '.') {
				count++;
			}
		}
	}
	// 현재위치 점 찍기 -> 하상좌우 판단 후 이동 가능하 곳은 양쪽 스택에 넣어두기
	// A에서 하나씩 Pop하면서 이동 -> 해당 위치가 이동 불가 경로일 경우 해당 위치를 기억해두기
	// A - B 하면 
	// B에는 이전 움직임 정보가 있기 때문에 해당 위치로 하나씩 0을 찍으며 이동
	// 최종적으로 B의 데이터를 이용해서 하나씩 Pop하고 스택을 찍는다.

	printf("Success\n");
	printf("Back count :  %d\n", count);

	return 0;
}